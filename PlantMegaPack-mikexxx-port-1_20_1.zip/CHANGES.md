# PMP port 1.1.0 - what changed

Project layout
- base/      your existing port, untouched classes + assets/data (edited, see below)
- src/       NEW Java (extension mod `pmp_mikexxx_ext`): 2-block hanging plants + colour tabs
- build jar: use build/libs/PlantMegaPack-mikexxx-port-1_20_1-1.1.0.jar  (the one WITHOUT "-ext")

Fixed / added
- Floating water plants rebuilt: flat pads lie on the water, flowers stand on them (own textures from 1.12.2:
  crested floating heart, variegated pond lily, water shield, hyacinth, lettuce). Water lilies = 6-petal flowers on a pad.
  Marked-flat plants from your reference are flat, the rest are 4-plane crosses.
- Hanging plants: new 2-block block (top hangs from ceiling / chain / wall bracket / leaves, bottom hangs below).
- Wisteria: removed the 9 duplicate "<Colour> Wisteria Vine" (kept the 13-colour Flowering Vine set).
- Flowers tab sorted alphabetically by plant family, then name.
- Added: Curled Iron Bracket, Curled Gold Bracket (1.7.10/1.6.4), Mixed Flowers hanging basket (1.6.4 only).
- 12 colour creative tabs (pmp_colors.json is auto-generated from textures; edit it to move items).
