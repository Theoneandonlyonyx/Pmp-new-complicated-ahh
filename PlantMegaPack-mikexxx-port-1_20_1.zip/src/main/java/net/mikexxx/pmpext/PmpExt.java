package net.mikexxx.pmpext;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Extension to the PMP port: two-block hanging plants + colour creative tabs.
 * Everything is registered under the existing "pmp_mikexxx" namespace so assets/recipes/loot stay where they are.
 */
@Mod(PmpExt.MODID)
public class PmpExt {
    public static final String MODID = "pmp_mikexxx_ext";
    public static final String NS = "pmp_mikexxx";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, NS);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, NS);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, NS);

    /** original tab name ("flowers") -> hanging item ids that belong in it */
    private static final Map<String, List<String>> HANGING_BY_TAB = new LinkedHashMap<>();
    private static final String[] TAB_NAMES = {"0_flowers", "1_plants", "2_crops", "3_aquatic", "4_trees", "5_food", "6_build"};
    private static final String[] TAB_KEYS = {"flowers", "plants", "crops", "aquatic", "trees", "food", "build"};

    /** colour tabs in display order */
    public static final String[] COLORS = {"burgundy", "red", "orange", "yellow", "lime", "green", "blue", "cyan",
            "purple", "pink", "white", "other"};

    public PmpExt() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        registerHanging();
        registerColorTabs();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
        bus.addListener(PmpExt::fillOriginalTabs);
    }

    private static JsonElement readJson(String path) {
        try (InputStream in = PmpExt.class.getResourceAsStream(path)) {
            if (in == null) return null;
            return JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        } catch (Exception e) {
            return null;
        }
    }

    private static void registerHanging() {
        JsonElement el = readJson("/pmp_hanging.json");
        if (el == null || !el.isJsonArray()) return;
        for (JsonElement je : (JsonArray) el) {
            JsonObject o = je.getAsJsonObject();
            final String id = o.get("id").getAsString();
            String tab = o.has("tab") ? o.get("tab").getAsString() : "plants";
            RegistryObject<Block> block = BLOCKS.register(id, () -> new HangingPlantBlock(
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.PLANT)
                            .noCollission()
                            .noOcclusion()
                            .instabreak()
                            .sound(SoundType.GRASS)
                            .pushReaction(PushReaction.DESTROY)));
            ITEMS.register(id, () -> new BlockItem(block.get(), new Item.Properties()));
            HANGING_BY_TAB.computeIfAbsent(tab, k -> new ArrayList<>()).add(id);
        }
    }

    private static void fillOriginalTabs(BuildCreativeModeTabContentsEvent event) {
        for (int i = 0; i < TAB_NAMES.length; i++) {
            ResourceKey<CreativeModeTab> key = ResourceKey.create(Registries.CREATIVE_MODE_TAB, new ResourceLocation(NS, TAB_NAMES[i]));
            if (!event.getTabKey().equals(key)) continue;
            List<String> ids = HANGING_BY_TAB.get(TAB_KEYS[i]);
            if (ids == null) continue;
            for (String id : ids) {
                Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(NS, id));
                if (item != null && item != Items.AIR) event.accept(item);
            }
        }
    }

    private static void registerColorTabs() {
        JsonElement el = readJson("/pmp_colors.json");
        if (el == null || !el.isJsonObject()) return;
        JsonObject root = el.getAsJsonObject();
        ResourceKey<CreativeModeTab> previous = ResourceKey.create(Registries.CREATIVE_MODE_TAB, new ResourceLocation(NS, "6_build"));
        for (String color : COLORS) {
            if (!root.has(color)) continue;
            final List<String> ids = new ArrayList<>();
            for (JsonElement e : root.getAsJsonArray(color)) ids.add(e.getAsString());
            if (ids.isEmpty()) continue;
            final String first = ids.get(0);
            final ResourceKey<CreativeModeTab> after = previous;
            RegistryObject<CreativeModeTab> tab = TABS.register("color_" + color, () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + NS + ".color_" + color))
                    .icon(() -> {
                        Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(NS, first));
                        return new ItemStack(it == null ? Items.OAK_SAPLING : it);
                    })
                    .withTabsBefore(after)
                    .displayItems((params, out) -> {
                        for (String id : ids) {
                            Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(NS, id));
                            if (it != null && it != Items.AIR) out.accept(it);
                        }
                    })
                    .build());
            previous = ResourceKey.create(Registries.CREATIVE_MODE_TAB, new ResourceLocation(NS, "color_" + color));
        }
    }
}
