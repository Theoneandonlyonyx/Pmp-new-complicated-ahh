package net.mikexxx.pmpext;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;

/**
 * Two block tall hanging plant. TOP is attached to the ceiling (or a chain / wall bracket / hook),
 * BOTTOM hangs below it. Break either half and both go.
 */
public class HangingPlantBlock extends Block {
    public enum Segment implements StringRepresentable {
        TOP("top"), BOTTOM("bottom");
        private final String name;
        Segment(String n) { this.name = n; }
        @Override public String getSerializedName() { return name; }
    }

    public static final EnumProperty<Segment> SEGMENT = EnumProperty.create("segment", Segment.class);
    private static final VoxelShape SHAPE = Block.box(2.0D, 0.0D, 2.0D, 14.0D, 16.0D, 14.0D);

    public HangingPlantBlock(Properties props) {
        super(props);
        this.registerDefaultState(this.stateDefinition.any().setValue(SEGMENT, Segment.TOP));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(SEGMENT);
    }

    /** What the top half may hang from: any block with a solid/centred underside, leaves, chains, brackets, hooks. */
    public static boolean canHangFrom(LevelReader level, BlockPos anchorPos) {
        BlockState s = level.getBlockState(anchorPos);
        if (s.is(Blocks.CHAIN) || s.is(BlockTags.LEAVES)) return true;
        ResourceLocation key = ForgeRegistries.BLOCKS.getKey(s.getBlock());
        if (key != null) {
            String p = key.getPath();
            if (p.contains("chain") || p.contains("bracket") || p.contains("hook") || p.contains("lantern_hanger")) return true;
        }
        return s.isFaceSturdy(level, anchorPos, Direction.DOWN) || Block.canSupportCenter(level, anchorPos, Direction.DOWN);
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos above = pos.above();
        if (state.getValue(SEGMENT) == Segment.TOP) {
            return canHangFrom(level, above);
        }
        BlockState up = level.getBlockState(above);
        return up.is(this) && up.getValue(SEGMENT) == Segment.TOP;
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        Level level = ctx.getLevel();
        BlockPos pos = ctx.getClickedPos();
        if (pos.getY() <= level.getMinBuildHeight()) return null;
        if (!level.getBlockState(pos.below()).canBeReplaced(ctx)) return null;
        BlockState state = this.defaultBlockState().setValue(SEGMENT, Segment.TOP);
        return state.canSurvive(level, pos) ? state : null;
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        level.setBlock(pos.below(), state.setValue(SEGMENT, Segment.BOTTOM), 3);
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level,
                                  BlockPos pos, BlockPos neighborPos) {
        Segment seg = state.getValue(SEGMENT);
        if (seg == Segment.TOP) {
            if (dir == Direction.DOWN && !(neighbor.is(this) && neighbor.getValue(SEGMENT) == Segment.BOTTOM)) {
                return Blocks.AIR.defaultBlockState();
            }
            if (dir == Direction.UP && !canHangFrom(level, neighborPos)) {
                return Blocks.AIR.defaultBlockState();
            }
        } else if (dir == Direction.UP && !(neighbor.is(this) && neighbor.getValue(SEGMENT) == Segment.TOP)) {
            return Blocks.AIR.defaultBlockState();
        }
        return state;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide && player.isCreative()) {
            BlockPos other = state.getValue(SEGMENT) == Segment.TOP ? pos.below() : pos.above();
            BlockState o = level.getBlockState(other);
            if (o.is(this)) {
                level.setBlock(other, Blocks.AIR.defaultBlockState(), 35);
            }
        }
        super.playerWillDestroy(level, pos, state, player);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }
}
